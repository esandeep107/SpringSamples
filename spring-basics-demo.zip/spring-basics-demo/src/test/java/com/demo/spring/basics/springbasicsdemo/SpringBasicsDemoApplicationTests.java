package com.demo.spring.basics.springbasicsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBasicsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
