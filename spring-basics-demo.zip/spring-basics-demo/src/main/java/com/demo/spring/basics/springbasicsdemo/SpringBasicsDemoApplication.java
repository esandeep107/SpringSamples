package com.demo.spring.basics.springbasicsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBasicsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBasicsDemoApplication.class, args);
	}

}
